package com.github.abel533.echarts.code;

/**
 * 线条类型，可选为：'curve'（曲线） | 'line'（直线）
 */
public enum LinkType {
    curve, line
}
